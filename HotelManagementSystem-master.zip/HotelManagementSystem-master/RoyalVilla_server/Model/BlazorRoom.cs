﻿namespace RoyalVilla_server.Model
{
    public class BlazorRoom
    {
        public int Id { get; set; }

        public string Roomname { get; set; }

        public double Price { get; set; }   

        public bool IsActive { get; set; }  
    }
}
